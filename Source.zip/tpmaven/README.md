# TP_Java_DevOps

**Compiler avec Maven :**
> mvn clean install [-X (debug)]

**Run le jar**
> java -jar tpmaven-0.0.1-SNAPSHOT.jar