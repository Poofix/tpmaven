# TP_Java_DevOps

*Le fichier Source.zip est mis à jour à chaque commit ! (Il est là pour être sûr que vous puissiez ouvrir ce TP.*

**Compiler avec Maven :**
> mvn clean install [-X (debug)]

**Run le jar**
> java -jar tpmaven-0.0.1-SNAPSHOT.jar